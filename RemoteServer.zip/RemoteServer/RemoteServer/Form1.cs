﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RemoteServer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textAddress.Text = GetLocaAddress();
            textStatus.Text = "OFF";
        }

        private string GetLocaAddress()
        {
            IPHostEntry ipEntry = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress[] addr = ipEntry.AddressList;
            return addr[1].ToString();
        }

        private void AddLog(string text)
        {
            textLog.Text += text + "\r\n";
            textLog.SelectionStart = textLog.Text.Length;
            textLog.ScrollToCaret();
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
            textStatus.Text = textStatus.Text.Equals("ON") ? "OFF" : "ON";

            if (textStatus.Text.Equals("ON"))
            {
                AddLog("Server started.");
            }
            else if (textStatus.Text.Equals("OFF"))
            {
                AddLog("Server stoped.");
            }
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == WindowState)
            {
                notifyIcon1.Visible = true;
                Hide();
            }
            else if (FormWindowState.Normal == WindowState)
            {
                notifyIcon1.Visible = false;
                ShowInTaskbar = true;
            }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
