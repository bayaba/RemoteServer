﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Drawing;
using System.Diagnostics;

namespace RemoteServer
{
    class Server
    {
        int Port;

        Thread Receiver;
        bool IsServerWorking = true;

        public UdpClient UdpListener;
        public IPEndPoint endPoint;

        Point oldPos = new Point();

        static bool HasClient = false;

        public Server(int port)
        {
            StartListening(port);
        }

        public void CloseServer()
        {
            IsServerWorking = false;

            if (Receiver != null)
            {
                Receiver.Abort();
                Receiver = null;
            }

            if (UdpListener != null)
            {
                WriteLine("DISCONNECT");
                UdpListener.Close();
                UdpListener = null;

                HasClient = false;
            }
        }

        void ReceiveUdp()
        {
            Form1.AddLog("Waiting for message..");
            endPoint = new IPEndPoint(IPAddress.Any, Port);

            while (IsServerWorking)
            {
                if (UdpListener.Available > 0)
                {
                    byte[] buff = UdpListener.Receive(ref endPoint);
                    string command = Encoding.ASCII.GetString(buff, 0, buff.Length);
                    CommandProcess(command);
                }
                Thread.Sleep(1);
            }
        }

        public void StartListening(int port)
        {
            Port = port;
            IsServerWorking = true;
            UdpListener = new UdpClient(port);
            Receiver = new Thread(ReceiveUdp);
            Receiver.IsBackground = true;
            Receiver.Start();
        }

        public bool IsConnected(Socket socket)
        {
            try
            {
                return !(socket.Poll(1, SelectMode.SelectRead) && socket.Available == 0);
            }
            catch (SocketException) { return false; }
        }

        void CommandProcess(string command)
        {
            var textArray = command.Split('\t');

            if (textArray[0].Equals("CONNECT")) // first message from client
            {
                WriteLine("CONNECTED\t100"); // default version is 100
                HasClient = true;
            }
            else if (textArray[0].Equals("KD")) // key down
            {
                Form1.SetKeyDown(textArray[1]);
            }
            else if (textArray[0].Equals("KU")) // key up
            {
                Form1.SetKeyUp(textArray[1]);
            }
            else if (textArray[0].Equals("MST")) // mouse moves begin
            {
                oldPos = Cursor.Position;
            }
            else if (textArray[0].Equals("MDN")) // mouse drag message
            {
                var x = oldPos.X + int.Parse(textArray[1]);
                var y = oldPos.Y + int.Parse(textArray[2]);
                Cursor.Position = new Point(x, y);
            }
            else if (textArray[0].Equals("LeftDown")) // mouse left button down
            {
                Form1.SetMouseEvent(0x02);
            }
            else if (textArray[0].Equals("LeftUp")) // mouse left button up
            {
                Form1.SetMouseEvent(0x04);
            }
            else if (textArray[0].Equals("RightDown")) // mouse right button down
            {
                Form1.SetMouseEvent(0x08);
            }
            else if (textArray[0].Equals("RightUp")) // mouse right button up
            {
                Form1.SetMouseEvent(0x10);
            }
            else if (textArray[0].Equals("WHL")) // mouse wheel
            {
                Form1.SetMouseEvent(0x800, int.Parse(textArray[1]));
            }
            else if (textArray[0].Equals("TURNOFF")) // turn off pc
            {
                Process.Start("shutdown", "/p");
            }
            else if (textArray[0].Equals("LOGOUT")) // log out
            {
                Process.Start("shutdown", "/l");
            }
            else if (textArray[0].Equals("REBOOT")) // reboot
            {
                Process.Start("shutdown", "/r");
            }
        }

        public void WriteLine(string text)
        {
            if (HasClient)
            {
                byte[] send_buffer = Encoding.ASCII.GetBytes(text);
                UdpListener.Send(send_buffer, send_buffer.Length, endPoint);
            }
        }
    }
}
