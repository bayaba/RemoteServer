﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RemoteServer
{
    public partial class Form1 : Form
    {
        public static Form1 Instance;
        private Server myServer = null;
        private string version = "1.0";

        [DllImport("user32.dll")]
        private static extern void keybd_event(byte bVk, byte bScan, int dwFlags, int dwExtraInfo);

        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint cButtons, UIntPtr dwExtraInfo);

        public Form1()
        {
            Instance = this;
            InitializeComponent();

            textAddress.Text = GetLocaAddress();
            textStatus.Text = "OFF";
            checkBox1.Checked = Properties.Settings.Default.startup;

            AddLog("Version " + version);
            SetStartup(true);
        }

        private void SetStartup(bool start = false)
        {
            RegistryKey rk = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);

            if (start && rk.GetValue("RemoteServer") != null)
            {
                ToggleStart();
                ShowInTaskbar = false;
            }

            if (checkBox1.Checked)
            {
                rk.SetValue("RemoteServer", Application.ExecutablePath);
            }
            else
            {
                rk.DeleteValue("RemoteServer", false);
            }
        }

        private string GetLocaAddress()
        {
            IPHostEntry ipEntry = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress[] addr = ipEntry.AddressList;

            foreach (var a in addr)
            {
                if (a.ToString().Contains(".")) return a.ToString();
            }
            return "";
        }

        public static void SetMouseEvent(int status, int amount = 0)
        {
            mouse_event((uint)status, (uint)Cursor.Position.X, (uint)Cursor.Position.Y, (uint)amount, UIntPtr.Zero);
        }

        public static void SetKeyDown(string key)
        {
            Keys result;
            if (Enum.TryParse(key, out result))
            {  
                keybd_event((byte)result, 0, 1, 0);
            }
        }

        public static void SetKeyUp(string key)
        {
            Keys result;
            if (Enum.TryParse(key, out result))
            {
                keybd_event((byte)result, 0, 1 | 2, 0);
            }
        }

        public static void AddLog(string text)
        {
            Instance.textLog.Text += text + "\r\n";
            Instance.textLog.SelectionStart = Instance.textLog.Text.Length;
            Instance.textLog.ScrollToCaret();
        }

        private void CloseServer()
        {
            if (myServer != null)
            {
                myServer.CloseServer();
                myServer = null;
            }
        }

        private void ToggleStart()
        {
            textStatus.Text = textStatus.Text.Equals("ON") ? "OFF" : "ON";

            if (textStatus.Text.Equals("ON"))
            {
                buttonStart.Text = "Stop";
                AddLog("Server started.");
                CloseServer();
                myServer = new Server(31987);
                WindowState = FormWindowState.Minimized;
            }
            else if (textStatus.Text.Equals("OFF"))
            {
                buttonStart.Text = "Start";
                CloseServer();
                AddLog("Server stoped.");
            }
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            ToggleStart();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == WindowState)
            {
                notifyIcon1.Visible = true;
                Hide();
            }
            else if (FormWindowState.Normal == WindowState)
            {
                notifyIcon1.Visible = false;
                ShowInTaskbar = true;
            }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            CloseServer();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default.startup = checkBox1.Checked;
            Properties.Settings.Default.Save();

            SetStartup();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
 
        }

        private void textAddress_KeyDown(object sender, KeyEventArgs e)
        {

        }
    }
}
